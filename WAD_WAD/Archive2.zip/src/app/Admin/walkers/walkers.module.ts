import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WalkersRoutingModule } from './walkers-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    WalkersRoutingModule
  ]
})
export class WalkersModule { }
