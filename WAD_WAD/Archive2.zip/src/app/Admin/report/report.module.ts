import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportRoutingModule } from './report-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ReportRoutingModule
  ]
})
export class ReportModule { }
