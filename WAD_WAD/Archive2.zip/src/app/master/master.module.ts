import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MasterRoutingModule } from './master-routing.module';
import { MasterComponent } from './master/master.component';
import { SidebarComponent } from '../core/components/sidebar/sidebar.component';
import { HeaderComponent } from '../core/components/header/header.component';
import { CoreModule } from '../core/core.module';

@NgModule({
  declarations: [
    MasterComponent,
  ],
  imports: [
    CommonModule,
    MasterRoutingModule,
  ]
})

export class MasterModule { }
