import { Component } from '@angular/core';
import { TitleService } from '../../services/title.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
public toogleTitle:boolean =false
public openNotifications:boolean=false
public titleDashboard:boolean = true
public titleOwners:boolean = false
public titleWalkers:boolean = false
public titleReport:boolean = false
constructor(public titleService:TitleService, private commonService:CommonService,private location:Location){}
ngOnInit(){
  this.changeTitle()
  this.toogleInnerTitle()
}
openNotificationsList(){
  this.openNotifications = !this.openNotifications
}
changeTitle(){
  this.titleService.ownersTitle.subscribe((res:any)=>{this.titleOwners=res;});
  this.titleService.dashboardTitle.subscribe((res:any)=>this.titleDashboard=res);
  this.titleService.walkersTitle.subscribe((res:any)=>this.titleWalkers=res);
  this.titleService.reportTitle.subscribe((res:any)=>this.titleReport=res)
}
toogleInnerTitle(){
  this.commonService.toggleTitle.subscribe((res:any)=>this.toogleTitle=res)
}
navigateToList(){
  this.location.back();
}
}
