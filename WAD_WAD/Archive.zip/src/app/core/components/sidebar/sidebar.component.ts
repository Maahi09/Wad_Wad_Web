
import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { TitleService } from '../../services/title.service';
import { CommonService } from 'src/app/shared/services/common.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent {
  public isOwnerActive:boolean = false
  public isWalkerActive:boolean = false
  constructor(private router:Router , private titleService:TitleService,private commonService:CommonService){}
  ngOnInit(){
    this.isActive()
  }
  //method for active component
  isActive(){
    this.commonService.ownerActive.subscribe((res:any)=>this.isOwnerActive=res);
    this.commonService.walkerActive.subscribe((res:any)=>this.isWalkerActive=res);
  }
  openOwnersList(){
    // this.router.navigate(['owners'])
    // this.titleService.ownersTitle.next(true)
    // this.titleService.dashboardTitle.next(false)
    // this.titleService.walkersTitle.next(false)
    // this.titleService.reportTitle.next(false)
    // this.titleService.binddata.next(false)
  }
  openWalkersList(){
    // this.router.navigate(['walkers'])
    // this.titleService.walkersTitle.next(true)
    // this.titleService.dashboardTitle.next(false)
    // this.titleService.ownersTitle.next(false)
    // this.titleService.reportTitle.next(false)
    // this.titleService.binddata.next(true)
  }
  openDashboard(){
    // this.router.navigate(['dashboard'])
    this.titleService.ownersTitle.next(false)
    this.titleService.walkersTitle.next(false)
    this.titleService.reportTitle.next(false)
    this.titleService.dashboardTitle.next(true)
    this.commonService.toggleTitle.next(false)
  }
  openReportList(){
    // this.router.navigate(['reports'])
    this.titleService.reportTitle.next(true)
    this.titleService.dashboardTitle.next(false)
    this.titleService.ownersTitle.next(false)
    this.titleService.walkersTitle.next(false)
  }
  public logOut(){
this.router.navigate([''])
  }
}
