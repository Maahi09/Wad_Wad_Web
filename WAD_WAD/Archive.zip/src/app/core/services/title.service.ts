import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TitleService {
  public headerTitle:string|undefined='Dashboard'
  constructor() { }
  public ownersTitle = new BehaviorSubject<boolean>(false) 
  public dashboardTitle = new BehaviorSubject<boolean>(true) 
  public walkersTitle = new BehaviorSubject<boolean>(false) 
  public reportTitle = new BehaviorSubject<boolean>(false) 
  public binddata =  new BehaviorSubject<boolean>(true)
}
