import {inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
export const authGuard: CanActivateFn = (route, state) => {
  const authToken = localStorage.getItem('authToken');
  const isAuthenticated = !authToken; 
  let router = inject(Router);
  if(isAuthenticated){
    alert('hello')
    router.navigate([''])
    return false;
  }
 
  return true
};
