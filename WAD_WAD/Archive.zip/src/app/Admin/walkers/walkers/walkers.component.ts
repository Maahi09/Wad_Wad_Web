import { Component } from '@angular/core';
import { WalkersService } from '../walkers.service';
import { TitleService } from 'src/app/core/services/title.service';
import { CommonService } from 'src/app/shared/services/common.service';

@Component({
  selector: 'app-walkers',
  templateUrl: './walkers.component.html',
  styleUrls: ['./walkers.component.css']
})
export class WalkersComponent {
public totalWalkers: any;
public walkerId:any;
public walkerDetails:any;
public totalJobs:any;
walkerCall:boolean|undefined;

constructor(private walkersService:WalkersService,private titleService:TitleService,private commonService:CommonService){}
ngOnInit(){
  this.getTotalWalkers()
}
//method to get total-walkers
getTotalWalkers(){
  this.walkersService.getWalkers().subscribe((res:any)=>{
    this.totalWalkers = res.data.totalWalker;
    this.walkersService.totalWalkersData.next(this.totalWalkers);
    this.titleService.walkersTitle.next(true)
    this.titleService.dashboardTitle.next(false)
    this.titleService.ownersTitle.next(false)
    this.titleService.reportTitle.next(false)
    this.titleService.binddata.next(true);
    this.commonService.disableUserJobDetails.next(false);
    this.commonService.toggleTitle.next(false);
    this.commonService.toggleCall.next(this.totalWalkers);
    this.walkerCall= false
    
  })
}





}
