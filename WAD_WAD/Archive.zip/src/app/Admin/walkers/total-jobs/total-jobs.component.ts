import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { WalkersService } from '../walkers.service';

@Component({
  selector: 'app-total-jobs',
  templateUrl: './total-jobs.component.html',
  styleUrls: ['./total-jobs.component.css']
})
export class TotalJobsComponent {
  public jobDetails:any;
  public jobId:any
  @Input() data: any;
  constructor(private router:Router,private walkersService:WalkersService){}
  ngOnInit(){
    this.getJobDetails()
  }
  public openJobInDetail(jobId:any){
    this.router.navigate(['job-details',jobId]);
  }
  //method to get total-jobs
  getJobDetails(){
  this.walkersService.totalJobDetails.subscribe((res:any)=>{res.map((item:any)=>{
    this.jobDetails=item;
    this.jobId = this.jobDetails.jobId;
  })})
}

}
