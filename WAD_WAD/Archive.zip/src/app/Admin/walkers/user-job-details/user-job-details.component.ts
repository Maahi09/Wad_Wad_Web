import { Component } from '@angular/core';
import { WalkersService } from '../walkers.service';

@Component({
  selector: 'app-user-job-details',
  templateUrl: './user-job-details.component.html',
  styleUrls: ['./user-job-details.component.css']
})
export class UserJobDetailsComponent {
public totalJobs:any
constructor(private walkersService:WalkersService){}
ngOnInit(){
  this.getTotalJobs()
 }
//method to get total-job
getTotalJobs(){
  this.walkersService.getJobDetails().subscribe((res:any)=>{
  this.totalJobs = res.data.PetDetails;
  this.walkersService.totalJobDetails.next(this.totalJobs)})}
}
