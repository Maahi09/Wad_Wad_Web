import { Component } from '@angular/core';
import { WalkersService } from '../walkers.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-job-details',
  templateUrl: './job-details.component.html',
  styleUrls: ['./job-details.component.css']
})
export class JobDetailsComponent {
  public jobId:any;
  public petDetails:any
  public petInfo:any
  public updatedPetInfo1:any
  public updatedPetInfo2:any
  public updatedPetInfo3:any
  public walkerData:any
  updatedPetInfo: any;
  updatedWalkerData: any;
constructor(private walkersService:WalkersService,private activatedRoute:ActivatedRoute){}
ngOnInit(){
  this.getjobId()
  this.getWalkWithPetDetails()
}
//method to get job-id
getjobId(){
  this.jobId=this.activatedRoute.snapshot.paramMap.get('id');
}
//method to get walking with pet details
getWalkWithPetDetails(){
  this.walkersService.getWalkWithPet(this.jobId).subscribe((res:any)=>{
    res.data.PetDetails.map((item:any)=>{this.petDetails=item}
    );
this.petInfo  =  res.data.PetInfo;
this.updatedPetInfo = {...this.petInfo};
delete this.updatedPetInfo.pooingTime;
delete this.updatedPetInfo.pottyTime;
delete this.updatedPetInfo.Images;

this.walkerData = res.data.WalkerData;
this.updatedWalkerData = {...this.walkerData};
delete this.updatedWalkerData.Review;
delete this.updatedWalkerData.Address;
  })
}
}
