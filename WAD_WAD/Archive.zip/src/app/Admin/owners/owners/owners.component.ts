import { Component, Input } from '@angular/core';
import { OwnersService } from '../owners.service';
import { TitleService } from 'src/app/core/services/title.service';
import { CommonService } from 'src/app/shared/services/common.service';

@Component({
  selector: 'app-owners',
  templateUrl: './owners.component.html',
  styleUrls: ['./owners.component.css']
})
export class OwnersComponent {
public totalOwners:any=[];
ownerCall:boolean = true;


constructor(private ownersService:OwnersService,private titleService:TitleService,private commonService:CommonService){
  this.getTotalOwners()  
}
ngOnInit() {
    
  }
  //method for getting total Owners
getTotalOwners(){
  this.ownersService.getOwners().subscribe((res:any)=>{
    this.totalOwners=res.data.totalOwners;
    console.log(this.totalOwners);
    
    this.ownersService.totalOwnersData.next(this.totalOwners);
    this.titleService.binddata.next(false);
    this.titleService.ownersTitle.next(true);
    this.titleService.dashboardTitle.next(false);
    this.titleService.walkersTitle.next(false);
    this.titleService.reportTitle.next(false);
    this.commonService.disableUserJobDetails.next(true);
    this.commonService.toggleTitle.next(false);
    this.commonService.toggleCall.next(this.totalOwners);
    this.ownerCall = true;
  })}

  
  
}
