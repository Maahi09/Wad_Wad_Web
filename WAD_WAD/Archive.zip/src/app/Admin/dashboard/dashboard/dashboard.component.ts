import { Component } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
constructor(private commonService:CommonService){}
ngOnInit(){
  this.commonService.ownerActive.next(false)
  this.commonService.walkerActive.next(false)
}
}
