import { Injectable } from '@angular/core';
import { flush } from '@angular/core/testing';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
public userId = new BehaviorSubject<number>(0)
public bindUserDetails = new BehaviorSubject<boolean>(true)
public disableUserJobDetails = new BehaviorSubject<boolean>(true)
public toggleTitle = new BehaviorSubject<boolean>(false)
public toggleCall = new BehaviorSubject({})
public petDetails = new BehaviorSubject({})
public petDetailsId = new BehaviorSubject(0)
// public ownerCall = new BehaviorSubject<boolean>(true)
// public walkerCall = new BehaviorSubject<boolean>(false)
public ownerData =  new BehaviorSubject([])
public walkerData =  new BehaviorSubject([])
public ownerActive =  new BehaviorSubject<boolean>(false)
public walkerActive =  new BehaviorSubject<boolean>(false)
constructor() { }
}
