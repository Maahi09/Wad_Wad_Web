import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-user-details-user-job-details',
  templateUrl: './user-details-user-job-details.component.html',
  styleUrls: ['./user-details-user-job-details.component.css']
})
export class UserDetailsUserJobDetailsComponent {
  public disbleJobDetails:boolean = true
  public userId:any
  constructor(private router:Router,private commonService:CommonService){}
ngOnInit(){
  this.disableUserJobDetails()
  this.getUserId()
}
  //method to disableUserJobDetails
  disableUserJobDetails(){
    this.commonService.disableUserJobDetails.subscribe((res:any)=>this.disbleJobDetails=res)
  }
  openUserDetails(){
    this.router.navigate([`user-details/${this.userId}`])
  }
  openJobDetails(){
    if(this.disbleJobDetails==false){
      this.router.navigate(['walkers/user-job-details'])
    }
    else{
      this.router.navigate([`user-details/${this.userId}`])
    }
  }
  //method to get userId
  getUserId(){
    this.commonService.userId.subscribe((res:any)=>this.userId=res)
  }
}
