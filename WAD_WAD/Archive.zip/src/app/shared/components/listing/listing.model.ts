//for total-owners response
export class totalOwners{
   [index:number]:{
    email:string;
    firstName:string;
    lastName:string;
    phoneNumber:string;
    userId:string;
   }
}
//for total-walkers response
export class totalWalkers{
    [index:number]:{
        email:string;
        firstName:string;
        lastName:string;
        phoneNumber:string;
        userId:string;
       }
}