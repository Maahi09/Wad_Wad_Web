import { Component, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OwnersService } from 'src/app/Admin/owners/owners.service';
import { WalkersService } from 'src/app/Admin/walkers/walkers.service';
import { TitleService } from 'src/app/core/services/title.service';
import { CommonService } from '../../services/common.service';
import { totalOwners, totalWalkers } from './listing.model';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.css']
})
export class ListingComponent {
public totalOwners:any
public totalWalkers:any
public bindData:boolean=true
public titleOwners:boolean = false
public titleWalkers:boolean = false
public titleReport:boolean = false;
@Input() ownerCall: any;

@Input() walkerCall: any;
@Input() ownerData:any;
@Input() walkerData:any;
constructor(private router:Router , private route: ActivatedRoute,private ownersService:OwnersService,private walkersService:WalkersService,private titleService:TitleService,private commonService:CommonService){
  console.log("ownerCall :",this.ownerCall);
  
}
ngOnInit() {
// this.route.snapshot.params['id'];
// this.getTotalOwners()
// this.getTotalWalkers()
this.bindTotalData()
this.changeTitle()
console.log(this.ownerData);

}
openUserDetails(userId:any){
this.router.navigate(['user-details',userId]);
this.commonService.userId.next(userId);
// this.commonService.ownerCall.next(this.ownerCall);
// this.commonService.walkerCall.next(this.walkerCall);
this.commonService.ownerData.next(this.ownerData);
this.commonService.walkerData.next(this.walkerData);
}

changeTitle(){
  this.titleService.ownersTitle.subscribe((res:boolean)=>{this.titleOwners=res});
  this.titleService.walkersTitle.subscribe((res:boolean)=>this.titleWalkers=res);
  this.titleService.reportTitle.subscribe((res:boolean)=>this.titleReport=res)
}
//method to get total owners with the help of behaviour subject
getTotalOwners(){
  this.ownersService.totalOwnersData.subscribe((res:totalOwners)=>{this.totalOwners=res;
    console.log(this.totalOwners);
    
    this.commonService.ownerActive.next(false)
  })
}
//method to get total walkers with the help of behaviour subject
getTotalWalkers(){
  this.walkersService.totalWalkersData.subscribe((res:totalWalkers)=>{this.totalWalkers=res;
    console.log(this.totalWalkers);
    
    this.commonService.walkerActive.next(false)
  })
}
//method to iterate on owners and walkers based on condition
 get listData(){
  if(this.bindData == true){
    return this.totalWalkers ;
  }else {
    return this.totalOwners ;
  }
 } 
//method to bind data on table
bindTotalData(){
  this.titleService.binddata.subscribe((res:boolean)=>this.bindData=res)
} 
}
