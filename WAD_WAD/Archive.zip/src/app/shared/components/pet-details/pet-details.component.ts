import { Component } from '@angular/core';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-pet-details',
  templateUrl: './pet-details.component.html',
  styleUrls: ['./pet-details.component.css']
})
export class PetDetailsComponent {
public petInfo:any;
public updatedPetDetails: any;  
public petData: any; 
public petId:number | undefined
public petDetails: any;
public petBehaviour: any;
constructor(private commonService:CommonService){}
ngOnInit(){
  this.getPetId()
  this.getPetDetails()
}
//method to get petId
getPetId(){
  this.commonService.petDetailsId.subscribe((res:any)=>this.petId=res)
}
//method to get pet-details
getPetDetails(){
  this.commonService.petDetails.subscribe((res:any)=>{console.log(res);this.petInfo= res.find((item:any)=>item.PetId===this.petId);console.log(this.petInfo);
  this.petDetails= {...this.petInfo};
  delete this.petDetails.PromptDetails;
  delete this.petDetails.images;
  delete this.petDetails.promptAns;
  delete this.petDetails.PetDescription;
  delete this.petDetails.PetId;
  delete this.petDetails.SpayedNeutered;
  delete this.petDetails.eatThings;
  delete this.petDetails.energyLevels;
  delete this.petDetails.feedingSchedule;
  delete this.petDetails.jump;
  delete this.petDetails.lat;
  delete this.petDetails.long;
  delete this.petDetails.pottySchedule;
  delete this.petDetails.rate;
  delete this.petDetails.socialShy  ;
  console.log(this.petDetails);
  console.log(this.petInfo);
  this.petBehaviour={...this.petInfo};
  delete this.petBehaviour.PromptDetails;
  delete this.petBehaviour.images;
  delete this.petBehaviour.promptAns;
  delete this.petBehaviour.PetDescription;
  delete this.petBehaviour.Age;
  delete this.petBehaviour.Breed;
  delete this.petBehaviour.Gender;
  delete this.petBehaviour.Weight;
  delete this.petBehaviour.address;
  delete this.petBehaviour.city;
  delete this.petBehaviour.PetId;

  }
  )
}

}
