import { Component } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { OwnersService } from 'src/app/Admin/owners/owners.service';
import { WalkersService } from 'src/app/Admin/walkers/walkers.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TitleService } from 'src/app/core/services/title.service';
import { ownerDetails, userDetails, walkerDetails } from './user-details.model';
import { combineLatest } from 'rxjs';
import { TmplAstRecursiveVisitor } from '@angular/compiler';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent {
public ownerDogsDetails:boolean = true  
public walkersDetails:boolean = false
public walkersProfile:boolean = false
public reportDetails:boolean= false
public bindUserDetails:boolean |undefined
public ownerDetails:userDetails | undefined
public updatedOwnerDetails:any
public walkersDetailedData:any 
public updatedWalkerDetails:any;
public userId :any;
public ownerCall=false;
public ownerCallId:any=[];
public walkerCall:any=true;
public walkerCallId:any=[];
public ownerData:any;
public retrivedOwnerData:any;
public walkerData:any;
public retrivedWalkerData:any;
public petDetails: any ;
public updatedPetDetails:any;
public walkerPromptDetails:any
public dogDetails:boolean = false
constructor(private commonService:CommonService, private ownersService:OwnersService,private walkersService:WalkersService,private activatedRoute: ActivatedRoute ,private titleService:TitleService){}
ngOnInit(){
  this.userId = this.activatedRoute.snapshot.paramMap.get('id');
  console.log(this.userId);
  // this.ownerGetCall()
  // this.walkerGetCall()
  this.ownerRes()
  this.walkerRes()
  if(this.ownerData){
    this.storeOwnerData()
  }
  else if(this.walkerData){
    this.storeWalkerData()
  }
  this.getUserDetails()
}
//method to open dog details
openDogDetails(petId:any){
this.dogDetails = !this.dogDetails ;
this.commonService.petDetailsId.next(petId)
}
//method to get ownerResponse
ownerRes(){
  this.commonService.ownerData.subscribe((res:any)=>{console.log(res);
  this.ownerData=res})
}
//method to get walkerResponse
walkerRes(){
  this.commonService.walkerData.subscribe((res:any)=>{console.log(res);
    this.walkerData=res})
}
//method to store owner-data in session storage
storeOwnerData(){
sessionStorage.setItem('ownerData',JSON.stringify(this.ownerData));
const storedOwnerData = sessionStorage.getItem('ownerData');
console.log(storedOwnerData);
if(storedOwnerData){
  this.retrivedOwnerData=JSON.parse(storedOwnerData)
}
}
//method to store walker-data in session storage
storeWalkerData(){
  sessionStorage.setItem('walkerData',JSON.stringify(this.walkerData));
  const storedWalkerData = sessionStorage.getItem('walkerData');
  if(storedWalkerData){
    this.retrivedWalkerData=JSON.parse(storedWalkerData)
  }
}
//method to do get call
getUserDetails(){
  console.log(this.retrivedOwnerData);
  console.log(this.retrivedWalkerData);
  const isOwner = this.retrivedOwnerData?.forEach((item:any)=>{
   if(item.userId===this.userId){
    this.getOwnerDetailedData()
   } });
  const isWalker = this.retrivedWalkerData?.forEach((item:any)=>{
   if(item.userId===this.userId){
    this.getWalkerDetailedData() 
   }});
}
// //method to do get call
// ownerGetCall(){
//    this.commonService.ownerCall.subscribe((res:any)=>{this.ownerCall=res;console.log(this.ownerCall);
//     if(this.ownerCall==true ){
//       this.getOwnerDetailedData()
//     }
//   })
// }
// //method to do get call
// walkerGetCall(){
//   this.commonService.walkerCall.subscribe((res:any)=>{this.walkerCall=res;console.log(this.walkerCall);
//     if(this.walkerCall==false ){
//       this.getWalkerDetailedData() 
//     }
//  })
// }
//method to get owner-details
getOwnerDetailedData(){
  this.ownersService.getOwnerDetails(this.userId).subscribe((res:ownerDetails)=>{
    this.ownerDetails = res.data?.UserDetails;
    this.updatedOwnerDetails= {...this.ownerDetails};
    delete this.updatedOwnerDetails.Name ;
    delete this.updatedOwnerDetails?.Profile; 
    this.petDetails = res.data?.petsDetails;
    this.commonService.petDetails.next(this.petDetails)
    this.bindUserDetails= true
    this.walkersDetails =false;
    this.walkersProfile =  false;
    this.ownerDogsDetails= true;
    this.commonService.toggleTitle.next(true);
    this.titleService.ownersTitle.next(true);
    this.titleService.walkersTitle.next(false); 
    this.commonService.ownerActive.next(true);
    this.commonService.walkerActive.next(false);
  }
  )
}
//method to get walker-details
getWalkerDetailedData(){
  this.walkersService.getWalkerDetails(this.userId).subscribe((res:walkerDetails)=>{
  this.walkerPromptDetails= res.data?.promptDetails;
    this.walkersDetailedData = res.data?.UserDetails;
    this.updatedWalkerDetails= {...this.walkersDetailedData};
    delete this.updatedWalkerDetails.Name;  
    delete this.updatedWalkerDetails?.Profile ; 
    delete this.updatedWalkerDetails.AboutSelf;
    delete this.updatedWalkerDetails.IdCardImage;
    delete this.updatedWalkerDetails.Images;
    this.bindUserDetails= false
    this.walkersDetails = true;
    this.walkersProfile = true;
    this.ownerDogsDetails= false;
    this.commonService.toggleTitle.next(true);
    this.titleService.ownersTitle.next(false)
    this.titleService.walkersTitle.next(true);
    this.commonService.walkerActive.next(true);
    this.commonService.ownerActive.next(false)
  }
  )
}
  //method for binding walker and owner details based on condition
  get userDetails(){
    if(this.bindUserDetails  == true){
      return this.ownerDetails ;
    }else {
      return this.walkersDetailedData ;
    }
  }
  //method for binding walker and owner details based on condition
  get updatedUserDetails(){
    if(this.bindUserDetails == true){
      return  this.updatedOwnerDetails;
    }else {
      return  this.updatedWalkerDetails;
    }
  }

}
