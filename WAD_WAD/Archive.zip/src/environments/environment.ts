export const environment ={
    BASE_URL:'https://f3bd-2405-201-2014-31ae-a86d-538e-e855-cfeb.ngrok-free.app/'
}